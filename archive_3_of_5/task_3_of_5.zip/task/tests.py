from test.tests import FastAPIStageTest

if __name__ == '__main__':    FastAPIStageTest().run_tests()