from app.services.llm_client import LLMClient
from app.models import RecipeResponse, RecipeStep
import json
from typing import List


class PlannerAgent:
    """
    Agent responsible for creating detailed, structured recipes from basic meal ideas.
    """

    def __init__(self, llm_client: LLMClient):
        self.llm_client = llm_client

    async def create_recipe(self, base_recipe: str) -> RecipeResponse:
        """
        Transform a basic recipe idea into a complete, structured recipe.

        Args:
            base_recipe: Basic recipe name or idea (e.g., "Vegan Stir Fry")

        Returns:
            RecipeResponse with detailed title, ingredients, and step-by-step instructions
        """
        prompt = (
            f"You are a professional chef and recipe developer. Given the basic recipe idea: '{base_recipe}'\n\n"
            f"Create a complete, detailed recipe and return it as a JSON object with the following structure:\n"
            f"{{\n"
            f'  "title": "A creative and appealing recipe title",\n'
            f'  "ingredients": ["ingredient1", "ingredient2", "ingredient3", ...],\n'
            f'  "steps": [\n'
            f'    {{"step_number": 1, "instruction": "First step instruction"}},\n'
            f'    {{"step_number": 2, "instruction": "Second step instruction"}},\n'
            f'    ...\n'
            f'  ]\n'
            f"}}\n\n"
            f"Requirements:\n"
            f"- The title should be creative and appetizing\n"
            f"- Include 5-8 realistic ingredients\n"
            f"- The ingredient list should include product, no quantities and measurement units\n"
            f"- Provide 5-8 clear, detailed cooking steps\n"
            f"- Each step should have a sequential step_number and detailed instruction\n"
            f"- Make the recipe practical and achievable for home cooking\n"
            f"- Ensure the recipe matches the original concept: {base_recipe}\n\n"
            f"Respond ONLY with valid JSON."
        )

        try:
            # Get response from LLM
            response = await self.llm_client.get_completion(prompt)

            # Extract data from response
            title = response.get("title", f"Delicious {base_recipe}")
            ingredients = response.get("ingredients", [])
            steps_data = response.get("steps", [])

            # Convert steps to RecipeStep objects
            steps = []
            for i, step_data in enumerate(steps_data, 1):
                if isinstance(step_data, dict):
                    step_number = step_data.get("step_number", i)
                    instruction = step_data.get("instruction", "")
                else:
                    # Handle case where step is just a string
                    step_number = i
                    instruction = str(step_data)

                steps.append(RecipeStep(
                    step_number=step_number,
                    instruction=instruction
                ))

            # Ensure we have at least some steps
            if not steps:
                steps = [
                    RecipeStep(step_number=1, instruction=f"Prepare all ingredients for {base_recipe}."),
                    RecipeStep(step_number=2, instruction="Cook according to your preferred method."),
                    RecipeStep(step_number=3, instruction="Season to taste and serve hot.")
                ]

            return RecipeResponse(
                title=title,
                ingredients=ingredients,
                steps=steps
            )

        except Exception as e:
            # Fallback response
            return RecipeResponse(
                title=f"Simple {base_recipe}",
                ingredients=["basic ingredients", "seasonings", "cooking oil"],
                steps=[
                    RecipeStep(step_number=1, instruction=f"Gather all ingredients for {base_recipe}."),
                    RecipeStep(step_number=2, instruction="Prepare ingredients by washing and chopping as needed."),
                    RecipeStep(step_number=3, instruction="Cook using your preferred cooking method."),
                    RecipeStep(step_number=4, instruction="Season to taste."),
                    RecipeStep(step_number=5, instruction="Serve hot and enjoy!")
                ]
            )