from fastapi import FastAPI, HTTPException
from app.models import (
    InventoryInput, DietInput, InventoryResponse, DietResponse,
    AskInput, AskResponse, PlanInput, RecipeResponse,
    RecommendInput, RecommendResponse
)
from app.services.llm_client import LLMClient
from app.agents.inventory_agent import InventoryAgent
from app.agents.diet_agent import DietAgent
from app.agents.manager_agent import ManagerAgent
from app.agents.planner_agent import PlannerAgent

# Initialize FastAPI app
app = FastAPI(title="Cooking Assistant API")

# Initialize LLM client
llm_client = LLMClient()

# Initialize agents
inventory_agent = InventoryAgent(llm_client)
diet_agent = DietAgent(llm_client)
manager_agent = ManagerAgent(inventory_agent, diet_agent)
planner_agent = PlannerAgent(llm_client)


@app.post("/inventory", response_model=InventoryResponse)
async def process_inventory(input_data: InventoryInput):
    """
    Process a list of inventory items and return usable items.
    """
    try:
        return await inventory_agent.process_items(input_data.items)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing inventory: {str(e)}")


@app.post("/diet", response_model=DietResponse)
async def process_diet(input_data: DietInput):
    """
    Process a list of items with dietary restrictions and suggest recipe ideas.
    """
    try:
        return await diet_agent.process_diet(input_data.items, input_data.diet)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing diet: {str(e)}")


@app.post("/ask", response_model=AskResponse)
async def process_ask(input_data: AskInput):
    """
    Unified endpoint that orchestrates the workflow between the Inventory Agent
    and Diet Agent to process items and provide diet-specific suggestions.
    """
    try:
        result = await manager_agent.process_request(input_data.items, input_data.diet)
        return AskResponse(
            usable_items=result["usable_items"],
            diet_filtered=result["diet_filtered"],
            suggestions=result["suggestions"]
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing ask request: {str(e)}")


@app.post("/plan", response_model=RecipeResponse)
async def process_plan(input_data: PlanInput):
    """
    Transform a basic recipe idea into a complete, structured recipe.
    """
    try:
        return await planner_agent.create_recipe(input_data.base_recipe)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating recipe: {str(e)}")


@app.post("/recommend", response_model=RecommendResponse)
async def process_recommend(input_data: RecommendInput):
    """
    Combine inventory processing, diet filtering, and recipe planning to generate
    complete recipes based on user's items and dietary preferences.
    """
    # Validate recipe count
    if input_data.recipe_count < 1 or input_data.recipe_count > 5:
        raise HTTPException(
            status_code=400,
            detail="Recipe count must be between 1 and 5"
        )

    try:
        # Step 1: Use the manager agent to get diet-compatible suggestions
        manager_result = await manager_agent.process_request(input_data.items, input_data.diet)
        recipe_suggestions = manager_result["suggestions"]

        # Step 2: Limit to requested number of recipes
        limited_suggestions = recipe_suggestions[:input_data.recipe_count]

        # Step 3: Generate detailed recipes for each suggestion
        detailed_recipes = []
        for suggestion in limited_suggestions:
            try:
                recipe = await planner_agent.create_recipe(suggestion)
                detailed_recipes.append(recipe)
            except Exception as e:
                # If one recipe fails, continue with others
                print(f"Failed to create recipe for '{suggestion}': {e}")
                continue

        # Ensure we have at least one recipe
        if not detailed_recipes:
            # Fallback: create a simple recipe with available ingredients
            fallback_recipe = await planner_agent.create_recipe(
                f"{input_data.diet.capitalize()} dish with {', '.join(manager_result['diet_filtered'][:3])}"
            )
            detailed_recipes.append(fallback_recipe)

        return RecommendResponse(recipes=detailed_recipes)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating recommendations: {str(e)}")


@app.get("/")
async def root():
    """
    Root endpoint to verify the API is running.
    """
    return {"message": "Success"}