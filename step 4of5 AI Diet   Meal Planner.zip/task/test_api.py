import asyncio
import httpx
import json
import sys
import os
from typing import Dict, Any, List

# Set the API base URL - default to localhost if not specified
API_URL = os.getenv("API_URL", "http://localhost:8000")

# Test data
TEST_INVENTORY = ["tofu", "bell pepper", "garlic", "oil", "soy sauce", "rice", "broccoli"]
TEST_DIET = "vegan"
TEST_BASE_RECIPE = "Vegan Stir Fry"


async def test_root():
    """Test the root endpoint"""
    print("\n🔍 Testing root endpoint...")

    async with httpx.AsyncClient() as client:
        response = await client.get(f"{API_URL}/")

    if response.status_code == 200:
        print("✅ Root endpoint is working!")
        return True
    else:
        print(f"❌ Root endpoint failed: {response.status_code} - {response.text}")
        return False


async def test_inventory():
    """Test the inventory endpoint"""
    print("\n🔍 Testing inventory endpoint...")

    data = {"items": TEST_INVENTORY}

    async with httpx.AsyncClient() as client:
        response = await client.post(f"{API_URL}/inventory", json=data)

    if response.status_code == 200:
        result = response.json()
        usable_items = result.get("usable_items", [])
        print(f"✅ Inventory endpoint is working!")
        print(f"📋 Usable items: {', '.join(usable_items)}")
        return True
    else:
        print(f"❌ Inventory endpoint failed: {response.status_code} - {response.text}")
        return False


async def test_diet():
    """Test the diet endpoint"""
    print("\n🔍 Testing diet endpoint...")

    data = {"items": TEST_INVENTORY, "diet": TEST_DIET}

    async with httpx.AsyncClient() as client:
        response = await client.post(f"{API_URL}/diet", json=data)

    if response.status_code == 200:
        result = response.json()
        compatible_items = result.get("compatible_items", [])
        suggested_recipes = result.get("suggested_recipe_ideas", [])

        print(f"✅ Diet endpoint is working!")
        print(f"📋 Compatible items: {', '.join(compatible_items)}")
        print(f"📋 Suggested recipes: {', '.join(suggested_recipes[:3])}...")
        return True
    else:
        print(f"❌ Diet endpoint failed: {response.status_code} - {response.text}")
        return False


async def test_ask():
    """Test the ask endpoint"""
    print("\n🔍 Testing ask endpoint...")

    data = {"items": TEST_INVENTORY, "diet": TEST_DIET}

    async with httpx.AsyncClient() as client:
        response = await client.post(f"{API_URL}/ask", json=data)

    if response.status_code == 200:
        result = response.json()
        usable_items = result.get("usable_items", [])
        diet_filtered = result.get("diet_filtered", [])
        suggestions = result.get("suggestions", [])

        print(f"✅ Ask endpoint is working!")
        print(f"📋 Usable items: {', '.join(usable_items[:3])}...")
        print(f"📋 Diet filtered: {', '.join(diet_filtered[:3])}...")
        print(f"📋 Suggestions: {', '.join(suggestions[:3])}...")
        return True
    else:
        print(f"❌ Ask endpoint failed: {response.status_code} - {response.text}")
        return False


async def test_plan():
    """Test the plan endpoint"""
    print("\n🔍 Testing plan endpoint...")

    data = {"base_recipe": TEST_BASE_RECIPE}

    async with httpx.AsyncClient() as client:
        response = await client.post(f"{API_URL}/plan", json=data)

    if response.status_code == 200:
        result = response.json()
        title = result.get("title", "")
        ingredients = result.get("ingredients", [])
        steps = result.get("steps", [])

        print(f"✅ Plan endpoint is working!")
        print(f"📋 Recipe title: {title}")
        print(f"📋 Ingredients: {', '.join(ingredients[:5])}...")
        print(f"📋 Steps: {len(steps)} steps included")

        # Validate step structure
        if steps and all(isinstance(step, dict) and "step_number" in step and "instruction" in step for step in steps):
            print(f"✅ Recipe steps are properly structured")
            # Print first two steps as example
            for step in steps[:2]:
                print(f"   Step {step['step_number']}: {step['instruction'][:50]}...")
        else:
            print(f"❌ Recipe steps are not properly structured")

        return True
    else:
        print(f"❌ Plan endpoint failed: {response.status_code} - {response.text}")
        return False


async def test_recommend():
    """Test the recommend endpoint"""
    print("\n🔍 Testing recommend endpoint...")

    data = {
        "items": TEST_INVENTORY,
        "diet": TEST_DIET,
        "recipe_count": 2
    }

    async with httpx.AsyncClient() as client:
        response = await client.post(f"{API_URL}/recommend", json=data)

    if response.status_code == 200:
        result = response.json()
        recipes = result.get("recipes", [])

        print(f"✅ Recommend endpoint is working!")
        print(f"📋 Number of recipes: {len(recipes)}")

        if recipes:
            # Validate the first recipe
            recipe = recipes[0]
            title = recipe.get("title", "")
            ingredients = recipe.get("ingredients", [])
            steps = recipe.get("steps", [])

            print(f"📋 First recipe title: {title}")
            print(f"📋 Ingredients: {', '.join(ingredients[:5])}...")
            print(f"📋 Steps: {len(steps)} steps included")

            # Print first step as example
            if steps:
                first_step = steps[0]
                print(f"   Step {first_step['step_number']}: {first_step['instruction'][:50]}...")

        return True
    else:
        print(f"❌ Recommend endpoint failed: {response.status_code} - {response.text}")
        return False


async def run_tests():
    """Run all tests and calculate success rate"""
    print("🚀 Starting API tests...\n")

    # Store all test results
    results = {
        "root": await test_root(),
        "inventory": await test_inventory(),
        "diet": await test_diet(),
        "ask": await test_ask(),
        "plan": await test_plan(),
        "recommend": await test_recommend()
    }

    # Calculate success rate
    total = len(results)
    passed = sum(1 for result in results.values() if result)

    # Print summary
    print("\n📊 Test Summary:")
    print(f"Total tests: {total}")
    print(f"Passed: {passed}")
    print(f"Failed: {total - passed}")

    success_percentage = (passed / total) * 100
    print(f"Success rate: {success_percentage:.1f}%")

    # Print individual test results
    print("\nDetailed Results:")
    for test_name, passed in results.items():
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"{test_name}: {status}")

    # Exit with appropriate code
    if passed == total:
        print("\n🎉 All tests passed successfully!")
        return 0
    else:
        print("\n⚠️ Some tests failed. Check the logs above for details.")
        return 1


if __name__ == "__main__":
    # Run the tests
    exit_code = asyncio.run(run_tests())

    # Exit with appropriate code
    sys.exit(exit_code)