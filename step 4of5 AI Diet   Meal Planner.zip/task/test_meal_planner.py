import asyncio
import httpx
import json
import os
import sys
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configuration
API_URL = "http://localhost:8000"
GREEN = "\033[92m"
RED = "\033[91m"
RESET = "\033[0m"
YELLOW = "\033[93m"

# Test data
test_inventory = ["tofu", "bell pepper", "garlic", "oil", "rice", "soy sauce", "broccoli"]
test_diet = "vegan"
test_recipe = "Vegan Stir Fry"


def print_success(message):
    print(f"{GREEN}✓ {message}{RESET}")


def print_error(message):
    print(f"{RED}✗ {message}{RESET}")


def print_header(message):
    print(f"\n{YELLOW}==== {message} ===={RESET}")


async def test_root_endpoint():
    print_header("Testing Root Endpoint")

    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(f"{API_URL}/")

            if response.status_code == 200:
                print_success(f"Root endpoint returned status code {response.status_code}")
                print(f"Response: {response.json()}")
                return True
            else:
                print_error(f"Root endpoint returned unexpected status code {response.status_code}")
                print(f"Response: {response.text}")
                return False

        except Exception as e:
            print_error(f"Error testing root endpoint: {str(e)}")
            return False


async def test_inventory_endpoint():
    print_header("Testing Inventory Endpoint")

    async with httpx.AsyncClient() as client:
        try:
            payload = {"items": test_inventory}
            response = await client.post(f"{API_URL}/inventory", json=payload)

            if response.status_code == 200:
                print_success(f"Inventory endpoint returned status code {response.status_code}")
                result = response.json()
                print(f"Usable items: {result.get('usable_items')}")
                print(f"Message: {result.get('message')}")
                return result.get('usable_items', [])
            else:
                print_error(f"Inventory endpoint returned unexpected status code {response.status_code}")
                print(f"Response: {response.text}")
                return []

        except Exception as e:
            print_error(f"Error testing inventory endpoint: {str(e)}")
            return []


async def test_diet_endpoint(items):
    print_header("Testing Diet Endpoint")

    async with httpx.AsyncClient() as client:
        try:
            payload = {"items": items, "diet": test_diet}
            response = await client.post(f"{API_URL}/diet", json=payload)

            if response.status_code == 200:
                print_success(f"Diet endpoint returned status code {response.status_code}")
                result = response.json()
                print(f"Compatible items: {result.get('compatible_items')}")
                print(f"Suggested recipes: {result.get('suggested_recipe_ideas')}")
                return True
            else:
                print_error(f"Diet endpoint returned unexpected status code {response.status_code}")
                print(f"Response: {response.text}")
                return False

        except Exception as e:
            print_error(f"Error testing diet endpoint: {str(e)}")
            return False


async def test_ask_endpoint():
    print_header("Testing Ask Endpoint")

    async with httpx.AsyncClient() as client:
        try:
            payload = {"items": test_inventory, "diet": test_diet}
            response = await client.post(f"{API_URL}/ask", json=payload)

            if response.status_code == 200:
                print_success(f"Ask endpoint returned status code {response.status_code}")
                result = response.json()
                print(f"Usable items: {result.get('usable_items')}")
                print(f"Diet filtered items: {result.get('diet_filtered')}")
                print(f"Suggestions: {result.get('suggestions')}")
                return True
            else:
                print_error(f"Ask endpoint returned unexpected status code {response.status_code}")
                print(f"Response: {response.text}")
                return False

        except Exception as e:
            print_error(f"Error testing ask endpoint: {str(e)}")
            return False


async def test_plan_endpoint():
    print_header("Testing Plan Endpoint")

    async with httpx.AsyncClient() as client:
        try:
            payload = {"base_recipe": test_recipe}
            response = await client.post(f"{API_URL}/plan", json=payload)

            if response.status_code == 200:
                print_success(f"Plan endpoint returned status code {response.status_code}")
                result = response.json()
                print(f"Recipe title: {result.get('title')}")
                print(f"Ingredients: {result.get('ingredients')}")

                steps = result.get('steps', [])
                if steps:
                    print("Steps:")
                    for step in steps:
                        print(f"  {step.get('step_number')}. {step.get('instruction')}")

                # Validate recipe structure
                if not result.get('title'):
                    print_error("Recipe is missing a title")
                    return False

                if not result.get('ingredients'):
                    print_error("Recipe is missing ingredients")
                    return False

                if not steps:
                    print_error("Recipe is missing steps")
                    return False

                # Check for step numbering
                step_numbers = [step.get('step_number') for step in steps]
                expected_numbers = list(range(1, len(steps) + 1))

                if sorted(step_numbers) != expected_numbers:
                    print_error(f"Step numbers are not sequential: {step_numbers}")
                    return False

                print_success("Recipe structure is valid")
                return True

            else:
                print_error(f"Plan endpoint returned unexpected status code {response.status_code}")
                print(f"Response: {response.text}")
                return False

        except Exception as e:
            print_error(f"Error testing plan endpoint: {str(e)}")
            return False


async def test_recommend_endpoint():
    print_header("Testing Recommend Endpoint")

    async with httpx.AsyncClient() as client:
        try:
            payload = {
                "items": test_inventory,
                "diet": test_diet,
                "recipe_count": 2
            }
            response = await client.post(f"{API_URL}/recommend", json=payload)

            if response.status_code == 200:
                print_success(f"Recommend endpoint returned status code {response.status_code}")
                result = response.json()
                recipes = result.get('recipes', [])

                print(f"Number of recipes generated: {len(recipes)}")

                if len(recipes) != 2:
                    print_error(f"Expected 2 recipes, got {len(recipes)}")
                    return False

                # Validate each recipe
                for i, recipe in enumerate(recipes):
                    print(f"\nRecipe {i + 1}: {recipe.get('title')}")
                    print(f"Ingredients: {recipe.get('ingredients')}")

                    steps = recipe.get('steps', [])
                    if steps:
                        print("Steps:")
                        for step in steps:
                            print(f"  {step.get('step_number')}. {step.get('instruction')}")

                    # Basic validation
                    if not recipe.get('title'):
                        print_error(f"Recipe {i + 1} is missing a title")
                        return False

                    if not recipe.get('ingredients'):
                        print_error(f"Recipe {i + 1} is missing ingredients")
                        return False

                    if not steps:
                        print_error(f"Recipe {i + 1} is missing steps")
                        return False

                print_success("All recipes are valid")
                return True

            else:
                print_error(f"Recommend endpoint returned unexpected status code {response.status_code}")
                print(f"Response: {response.text}")
                return False

        except Exception as e:
            print_error(f"Error testing recommend endpoint: {str(e)}")
            return False


async def run_all_tests():
    print("Starting API endpoint tests...")

    # Test if API is running
    if not await test_root_endpoint():
        print_error("API not running. Make sure to start the server with 'uvicorn main:app --reload'")
        return

    # Test inventory endpoint
    usable_items = await test_inventory_endpoint()

    # Test diet endpoint
    await test_diet_endpoint(usable_items)

    # Test ask endpoint
    await test_ask_endpoint()

    # Test new endpoints
    await test_plan_endpoint()
    await test_recommend_endpoint()

    print("\nTests completed!")


if __name__ == "__main__":
    print("AI Diet & Meal Planner API Test")
    print("==============================")

    # Check if API key is set
    api_key = os.getenv("LLM_API_KEY")
    if not api_key:
        print_error("LLM_API_KEY not found in environment variables or .env file")
        print("Please set your Groq API key in a .env file or as an environment variable")
        sys.exit(1)

    # Run the tests
    asyncio.run(run_all_tests())