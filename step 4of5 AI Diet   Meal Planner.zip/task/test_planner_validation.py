import asyncio
import httpx
import json
import sys
import os
from typing import Dict, Any, List

# Set the API base URL - default to localhost if not specified
API_URL = os.getenv("API_URL", "http://localhost:8000")

# Test cases
TEST_CASES = [
    {"base_recipe": "Vegan Stir Fry"},
    {"base_recipe": "Gluten-Free Pancakes"},
    {"base_recipe": "Keto Burger"},
    {"base_recipe": "Mediterranean Salad"},
    {"base_recipe": "Paleo Chicken"},
]

# Recommend test cases
RECOMMEND_TEST_CASES = [
    {
        "items": ["tofu", "bell pepper", "garlic", "oil", "soy sauce", "rice", "broccoli"],
        "diet": "vegan",
        "recipe_count": 2
    },
    {
        "items": ["eggs", "cheese", "tomato", "spinach", "bacon", "avocado"],
        "diet": "keto",
        "recipe_count": 1
    },
    {
        "items": ["chicken", "olive oil", "lemon", "garlic", "oregano", "tomato", "cucumber"],
        "diet": "mediterranean",
        "recipe_count": 3
    }
]


def validate_recipe(recipe: Dict[str, Any]) -> List[str]:
    """
    Validate a recipe structure and return a list of validation errors.

    Args:
        recipe: Recipe dictionary to validate

    Returns:
        List of validation error messages, empty if valid
    """
    errors = []

    # Check required fields
    if "title" not in recipe:
        errors.append("Missing 'title' field")
    elif not isinstance(recipe["title"], str) or not recipe["title"].strip():
        errors.append("'title' field must be a non-empty string")

    if "ingredients" not in recipe:
        errors.append("Missing 'ingredients' field")
    elif not isinstance(recipe["ingredients"], list):
        errors.append("'ingredients' field must be a list")
    elif not all(isinstance(item, str) for item in recipe["ingredients"]):
        errors.append("All ingredients must be strings")
    elif len(recipe["ingredients"]) < 1:
        errors.append("Recipe should have at least one ingredient")

    if "steps" not in recipe:
        errors.append("Missing 'steps' field")
    elif not isinstance(recipe["steps"], list):
        errors.append("'steps' field must be a list")
    elif len(recipe["steps"]) < 1:
        errors.append("Recipe should have at least one step")
    else:
        # Validate each step
        for i, step in enumerate(recipe["steps"]):
            if not isinstance(step, dict):
                errors.append(f"Step {i + 1} must be a dictionary")
                continue

            if "step_number" not in step:
                errors.append(f"Step {i + 1} missing 'step_number' field")
            elif not isinstance(step["step_number"], int):
                errors.append(f"Step {i + 1} 'step_number' must be an integer")

            if "instruction" not in step:
                errors.append(f"Step {i + 1} missing 'instruction' field")
            elif not isinstance(step["instruction"], str) or not step["instruction"].strip():
                errors.append(f"Step {i + 1} 'instruction' must be a non-empty string")

    return errors


async def test_plan_endpoint():
    """Test the plan endpoint with multiple cases"""
    print("\n🔍 Testing /plan endpoint with multiple cases...")

    results = []

    async with httpx.AsyncClient() as client:
        for i, test_case in enumerate(TEST_CASES):
            print(f"\nTesting case {i + 1}: {test_case['base_recipe']}")

            response = await client.post(f"{API_URL}/plan", json=test_case)

            if response.status_code != 200:
                print(f"❌ Request failed: {response.status_code} - {response.text}")
                results.append({
                    "test_case": test_case,
                    "status": "failed",
                    "errors": [f"HTTP Error {response.status_code}"]
                })
                continue

            try:
                recipe = response.json()
                validation_errors = validate_recipe(recipe)

                if validation_errors:
                    print(f"❌ Validation failed with {len(validation_errors)} errors:")
                    for error in validation_errors:
                        print(f"  - {error}")
                    results.append({
                        "test_case": test_case,
                        "status": "invalid",
                        "errors": validation_errors
                    })
                else:
                    print(f"✅ Recipe validated successfully:")
                    print(f"  Title: {recipe['title']}")
                    print(f"  Ingredients: {len(recipe['ingredients'])} items")
                    print(f"  Steps: {len(recipe['steps'])} steps")
                    results.append({
                        "test_case": test_case,
                        "status": "valid",
                        "errors": []
                    })
            except json.JSONDecodeError:
                print("❌ Response is not valid JSON")
                results.append({
                    "test_case": test_case,
                    "status": "invalid_json",
                    "errors": ["Response is not valid JSON"]
                })

    return results


async def test_recommend_endpoint():
    """Test the recommend endpoint with multiple cases"""
    print("\n🔍 Testing /recommend endpoint with multiple cases...")

    results = []

    async with httpx.AsyncClient() as client:
        for i, test_case in enumerate(RECOMMEND_TEST_CASES):
            print(f"\nTesting case {i + 1}: {test_case['diet']} diet with {len(test_case['items'])} items")

            response = await client.post(f"{API_URL}/recommend", json=test_case)

            if response.status_code != 200:
                print(f"❌ Request failed: {response.status_code} - {response.text}")
                results.append({
                    "test_case": test_case,
                    "status": "failed",
                    "errors": [f"HTTP Error {response.status_code}"]
                })
                continue

            try:
                result = response.json()

                if "recipes" not in result or not isinstance(result["recipes"], list):
                    print("❌ Response missing 'recipes' array")
                    results.append({
                        "test_case": test_case,
                        "status": "invalid",
                        "errors": ["Response missing 'recipes' array"]
                    })
                    continue

                recipes = result["recipes"]
                print(f"Received {len(recipes)} recipes (expected {test_case['recipe_count']})")

                if len(recipes) != test_case["recipe_count"]:
                    print(f"❌ Received wrong number of recipes: {len(recipes)} instead of {test_case['recipe_count']}")
                    results.append({
                        "test_case": test_case,
                        "status": "count_mismatch",
                        "errors": [f"Received {len(recipes)} recipes instead of {test_case['recipe_count']}"]
                    })
                    continue

                # Validate each recipe
                all_valid = True
                validation_errors = []

                for j, recipe in enumerate(recipes):
                    errors = validate_recipe(recipe)
                    if errors:
                        all_valid = False
                        validation_errors.append({
                            "recipe_index": j,
                            "errors": errors
                        })

                if all_valid:
                    print(f"✅ All recipes validated successfully")
                    results.append({
                        "test_case": test_case,
                        "status": "valid",
                        "errors": []
                    })
                else:
                    print(f"❌ {len(validation_errors)} recipes failed validation")
                    results.append({
                        "test_case": test_case,
                        "status": "invalid",
                        "errors": validation_errors
                    })

            except json.JSONDecodeError:
                print("❌ Response is not valid JSON")
                results.append({
                    "test_case": test_case,
                    "status": "invalid_json",
                    "errors": ["Response is not valid JSON"]
                })

    return results


async def run_validation_tests():
    """Run all validation tests and summarize results"""
    print("🚀 Starting Planner Agent validation tests...\n")

    # Run tests
    plan_results = await test_plan_endpoint()
    recommend_results = await test_recommend_endpoint()

    # Summarize results
    print("\n📊 Validation Summary:")

    # Plan endpoint summary
    plan_success = sum(1 for r in plan_results if r["status"] == "valid")
    print(f"Plan endpoint: {plan_success}/{len(plan_results)} tests passed")

    # Recommend endpoint summary
    recommend_success = sum(1 for r in recommend_results if r["status"] == "valid")
    print(f"Recommend endpoint: {recommend_success}/{len(recommend_results)} tests passed")

    # Overall result
    total_tests = len(plan_results) + len(recommend_results)
    total_passed = plan_success + recommend_success
    success_percentage = (total_passed / total_tests) * 100 if total_tests > 0 else 0

    print(f"\nOverall success rate: {success_percentage:.1f}% ({total_passed}/{total_tests})")

    # Determine success
    if total_passed == total_tests:
        print("\n🎉 All validation tests passed! The Planner Agent is working correctly.")
        return 0
    else:
        print("\n⚠️ Some validation tests failed. Check the logs above for details.")
        return 1


if __name__ == "__main__":
    # Run the validation tests
    exit_code = asyncio.run(run_validation_tests())

    # Exit with appropriate code
    sys.exit(exit_code)