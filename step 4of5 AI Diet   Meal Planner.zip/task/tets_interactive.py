import asyncio
import httpx
import json
import os
import sys
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configuration
API_URL = "http://localhost:8000"
GREEN = "\033[92m"
RED = "\033[91m"
RESET = "\033[0m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
MAGENTA = "\033[95m"

# Valid diets
VALID_DIETS = ["vegan", "keto", "mediterranean", "gluten-free", "paleo"]


def clear_screen():
    """Clear the terminal screen."""
    os.system('cls' if os.name == 'nt' else 'clear')


def print_colored(color, message):
    """Print a message in the specified color."""
    print(f"{color}{message}{RESET}")


def print_title(title):
    """Print a section title."""
    print("\n" + "=" * 60)
    print_colored(YELLOW, f"  {title}")
    print("=" * 60)


def print_recipe(recipe):
    """Print a formatted recipe."""
    print_colored(CYAN, f"\n📝 {recipe.get('title', 'Recipe')}")
    print("-" * 40)

    print_colored(MAGENTA, "Ingredients:")
    for ingredient in recipe.get('ingredients', []):
        print(f"  • {ingredient}")

    print_colored(MAGENTA, "\nInstructions:")
    for step in recipe.get('steps', []):
        print(f"  {step.get('step_number')}. {step.get('instruction')}")
    print()


async def check_api_status():
    """Check if the API is running."""
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(f"{API_URL}/")
            if response.status_code == 200:
                return True
            return False
    except Exception:
        return False


async def inventory_test():
    """Test the inventory endpoint interactively."""
    print_title("Inventory Processing Test")

    # Get user input
    print("Enter your inventory items (comma-separated):")
    items_input = input("> ")
    items = [item.strip() for item in items_input.split(",")]

    print_colored(YELLOW, f"\nProcessing {len(items)} items...")

    # Call API
    async with httpx.AsyncClient() as client:
        try:
            payload = {"items": items}
            response = await client.post(f"{API_URL}/inventory", json=payload)

            if response.status_code == 200:
                result = response.json()
                usable_items = result.get('usable_items', [])
                message = result.get('message', '')

                print_colored(GREEN, "\n✓ Inventory processed successfully!")
                print(f"Message: {message}")
                print_colored(CYAN, "\nUsable Items:")
                for item in usable_items:
                    print(f"  • {item}")

                return usable_items
            else:
                print_colored(RED, f"\n✗ Error: {response.status_code}")
                print(response.text)
                return []

        except Exception as e:
            print_colored(RED, f"\n✗ Error: {str(e)}")
            return []


async def diet_test():
    """Test the diet endpoint interactively."""
    print_title("Diet Processing Test")

    # Get user input for inventory
    print("Enter your inventory items (comma-separated):")
    items_input = input("> ")
    items = [item.strip() for item in items_input.split(",")]

    # Get user input for diet
    print(f"\nChoose a diet ({', '.join(VALID_DIETS)}):")
    diet = input("> ").lower()

    if diet not in VALID_DIETS:
        print_colored(RED, f"\n✗ Invalid diet: {diet}")
        print(f"Valid options are: {', '.join(VALID_DIETS)}")
        return

    print_colored(YELLOW, f"\nProcessing {len(items)} items with {diet} diet...")

    # Call API
    async with httpx.AsyncClient() as client:
        try:
            payload = {"items": items, "diet": diet}
            response = await client.post(f"{API_URL}/diet", json=payload)

            if response.status_code == 200:
                result = response.json()
                compatible_items = result.get('compatible_items', [])
                recipe_ideas = result.get('suggested_recipe_ideas', [])

                print_colored(GREEN, "\n✓ Diet processed successfully!")

                print_colored(CYAN, "\nCompatible Items:")
                for item in compatible_items:
                    print(f"  • {item}")

                print_colored(CYAN, "\nSuggested Recipe Ideas:")
                for i, idea in enumerate(recipe_ideas, 1):
                    print(f"  {i}. {idea}")

            else:
                print_colored(RED, f"\n✗ Error: {response.status_code}")
                print(response.text)

        except Exception as e:
            print_colored(RED, f"\n✗ Error: {str(e)}")


async def ask_test():
    """Test the ask endpoint interactively."""
    print_title("Combined Processing Test (Ask)")

    # Get user input for inventory
    print("Enter your inventory items (comma-separated):")
    items_input = input("> ")
    items = [item.strip() for item in items_input.split(",")]

    # Get user input for diet
    print(f"\nChoose a diet ({', '.join(VALID_DIETS)}):")
    diet = input("> ").lower()

    if diet not in VALID_DIETS:
        print_colored(RED, f"\n✗ Invalid diet: {diet}")
        print(f"Valid options are: {', '.join(VALID_DIETS)}")
        return

    print_colored(YELLOW, f"\nProcessing request...")

    # Call API
    async with httpx.AsyncClient() as client:
        try:
            payload = {"items": items, "diet": diet}
            response = await client.post(f"{API_URL}/ask", json=payload)

            if response.status_code == 200:
                result = response.json()
                usable_items = result.get('usable_items', [])
                diet_filtered = result.get('diet_filtered', [])
                suggestions = result.get('suggestions', [])

                print_colored(GREEN, "\n✓ Request processed successfully!")

                print_colored(CYAN, "\nUsable Items:")
                for item in usable_items:
                    print(f"  • {item}")

                print_colored(CYAN, f"\n{diet.capitalize()} Compatible Items:")
                for item in diet_filtered:
                    print(f"  • {item}")

                print_colored(CYAN, "\nSuggested Recipe Ideas:")
                for i, idea in enumerate(suggestions, 1):
                    print(f"  {i}. {idea}")

            else:
                print_colored(RED, f"\n✗ Error: {response.status_code}")
                print(response.text)

        except Exception as e:
            print_colored(RED, f"\n✗ Error: {str(e)}")


async def plan_test():
    """Test the plan endpoint interactively."""
    print_title("Recipe Planning Test")

    # Get user input for base recipe
    print("Enter a recipe idea:")
    base_recipe = input("> ")

    print_colored(YELLOW, f"\nGenerating detailed recipe for '{base_recipe}'...")

    # Call API
    async with httpx.AsyncClient() as client:
        try:
            payload = {"base_recipe": base_recipe}
            response = await client.post(f"{API_URL}/plan", json=payload)

            if response.status_code == 200:
                recipe = response.json()

                print_colored(GREEN, "\n✓ Recipe generated successfully!")
                print_recipe(recipe)

            else:
                print_colored(RED, f"\n✗ Error: {response.status_code}")
                print(response.text)

        except Exception as e:
            print_colored(RED, f"\n✗ Error: {str(e)}")


async def recommend_test():
    """Test the recommend endpoint interactively."""
    print_title("Recipe Recommendation Test")

    # Get user input for inventory
    print("Enter your inventory items (comma-separated):")
    items_input = input("> ")
    items = [item.strip() for item in items_input.split(",")]

    # Get user input for diet
    print(f"\nChoose a diet ({', '.join(VALID_DIETS)}):")
    diet = input("> ").lower()

    if diet not in VALID_DIETS:
        print_colored(RED, f"\n✗ Invalid diet: {diet}")
        print(f"Valid options are: {', '.join(VALID_DIETS)}")
        return

    # Get user input for number of recipes
    print("\nHow many recipes do you want (1-5):")
    try:
        recipe_count = int(input("> "))
        if recipe_count < 1 or recipe_count > 5:
            print_colored(RED, "\n✗ Recipe count must be between 1 and 5")
            return
    except ValueError:
        print_colored(RED, "\n✗ Please enter a valid number")
        return

    print_colored(YELLOW, f"\nGenerating {recipe_count} {diet} recipes...")

    # Call API
    async with httpx.AsyncClient() as client:
        try:
            payload = {"items": items, "diet": diet, "recipe_count": recipe_count}
            response = await client.post(f"{API_URL}/recommend", json=payload)

            if response.status_code == 200:
                result = response.json()
                recipes = result.get('recipes', [])

                print_colored(GREEN, f"\n✓ Generated {len(recipes)} recipes successfully!")

                for i, recipe in enumerate(recipes, 1):
                    print_colored(YELLOW, f"\nRecipe {i} of {len(recipes)}")
                    print_recipe(recipe)

                    # If more recipes to show, prompt to continue
                    if i < len(recipes):
                        input("Press Enter to see the next recipe...")

            else:
                print_colored(RED, f"\n✗ Error: {response.status_code}")
                print(response.text)

        except Exception as e:
            print_colored(RED, f"\n✗ Error: {str(e)}")


async def main_menu():
    """Display the main menu and handle user selection."""
    while True:
        clear_screen()
        print_title("AI Diet & Meal Planner - Interactive Testing")

        print("Choose a test to run:")
        print("  1. Inventory Processing")
        print("  2. Diet Processing")
        print("  3. Combined Processing (Ask)")
        print("  4. Recipe Planning")
        print("  5. Recipe Recommendation")
        print("  0. Exit")

        choice = input("\nEnter your choice: ")

        if choice == "1":
            await inventory_test()
        elif choice == "2":
            await diet_test()
        elif choice == "3":
            await ask_test()
        elif choice == "4":
            await plan_test()
        elif choice == "5":
            await recommend_test()
        elif choice == "0":
            print("\nExiting...")
            break
        else:
            print_colored(RED, "\nInvalid choice. Please try again.")

        input("\nPress Enter to continue...")


async def main():
    """Main function to run the interactive test."""
    # Check if API key is set
    api_key = os.getenv("LLM_API_KEY")
    if not api_key:
        print_colored(RED, "LLM_API_KEY not found in environment variables or .env file")
        print("Please set your Groq API key in a .env file or as an environment variable")
        sys.exit(1)

    # Check if the API is running
    print("Checking API status...")
    if not await check_api_status():
        print_colored(RED, "Error: API is not running")
        print("Please start the API server with 'uvicorn main:app --reload'")
        sys.exit(1)

    print_colored(GREEN, "API is running!")

    # Run the interactive menu
    await main_menu()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nExiting...")